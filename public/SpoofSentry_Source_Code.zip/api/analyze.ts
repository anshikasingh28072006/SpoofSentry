import type { IncomingMessage, ServerResponse } from 'http';

// Helper for Vercel Serverless Handler
export default async function handler(req: any, res: any) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed. Use POST.' });
  }

  try {
    const { from, return_path = '', dkim_header = '', subject = '', body = '', date = '', source = 'manual', headersUnavailable = false, gmail_metadata } = req.body || {};

    if (!from) {
      return res.status(400).json({ error: 'From address is required for email forensic evaluation.' });
    }

    const fromDomain = extractDomain(from);
    const returnPathDomain = extractDomain(return_path);
    const hasReturnPath = Boolean(returnPathDomain);
    const domainsMatch = (fromDomain && returnPathDomain) ? (fromDomain === returnPathDomain) : true;
    const domainMismatch = Boolean(fromDomain && returnPathDomain && fromDomain !== returnPathDomain);

    const [spfResult, dkimResult, dmarcResult] = await Promise.all([
      checkSpfDoH(fromDomain),
      checkDkimDoH(dkim_header, fromDomain),
      checkDmarcDoH(fromDomain)
    ]);

    const contentResult = analyzeContent(subject, body);
    const timingResult = analyzeTiming(date);

    const authPasses = [spfResult.status === 'PASS', dkimResult.status === 'PASS', dmarcResult.status === 'PASS'].filter(Boolean).length;
    const authFails = [spfResult.status === 'FAIL', dkimResult.status === 'FAIL', dmarcResult.status === 'FAIL'].filter(Boolean).length;

    const reasons: string[] = [];
    if (domainMismatch) {
      reasons.push(`Domain mismatch: From header (${fromDomain}) does not match Return-Path (${returnPathDomain}).`);
    }
    if (spfResult.status === 'FAIL') {
      reasons.push(`SPF validation failed for ${fromDomain}.`);
    } else if (spfResult.status === 'NONE') {
      reasons.push(`No SPF record published for ${fromDomain}.`);
    }
    if (dkimResult.status === 'FAIL') {
      reasons.push(`DKIM verification failed: selector not found in DNS.`);
    } else if (dkimResult.status === 'NONE') {
      reasons.push(`No DKIM signature present on message.`);
    }
    if (dmarcResult.policy === 'none_published') {
      reasons.push(`No DMARC policy on ${fromDomain} to enforce domain protection.`);
    } else if (dmarcResult.policy === 'none') {
      reasons.push(`DMARC policy is set to 'none' (monitoring only, not enforced).`);
    }

    let baseVerdict = 'SUSPICIOUS';
    if (domainMismatch || authFails >= 2 || (dmarcResult.policy === 'reject' && authPasses <= 1 && authFails >= 1)) {
      baseVerdict = 'SPOOFED';
    } else if (authPasses >= 2 && !domainMismatch) {
      baseVerdict = 'LEGITIMATE';
    }

    let finalVerdict = baseVerdict;
    let isEscalated = false;
    if (contentResult.risk_rating === 'HIGH') {
      if (baseVerdict === 'LEGITIMATE') {
        finalVerdict = 'SUSPICIOUS';
        isEscalated = true;
        reasons.push('Verdict escalated to SUSPICIOUS due to high-risk social engineering content triggers.');
      } else if (baseVerdict === 'SUSPICIOUS') {
        finalVerdict = 'SPOOFED';
        isEscalated = true;
        reasons.push('Verdict escalated to SPOOFED due to high-risk social engineering content triggers.');
      }
    }

    if (timingResult.is_off_hours) {
      reasons.push('Message timestamp falls during anomalous off-hours window (23:00 - 06:00).');
    }
    if (reasons.length === 0) {
      reasons.push('Authentication checks passed and sender domain alignment is verified.');
    }

    const assessmentReport = computeServerlessAssessment({
      spfStatus: spfResult.status,
      dkimStatus: dkimResult.status,
      dmarcStatus: dmarcResult.status,
      domainMismatch,
      headersUnavailable,
      urgencyCount: contentResult.urgency_count,
      financialCount: contentResult.financial_count,
      threatCount: contentResult.threat_count,
      linkCount: contentResult.link_count,
      hasIpLink: contentResult.raw_ip_links.length > 0,
      isOffHours: timingResult.is_off_hours
    });

    res.status(200).json({
      verdict: finalVerdict,
      base_verdict: baseVerdict,
      is_escalated: isEscalated,
      sender_alignment: {
        from_address: from,
        from_domain: fromDomain,
        return_path: return_path,
        return_path_domain: returnPathDomain,
        has_return_path: hasReturnPath,
        domains_aligned: domainsMatch,
        domain_mismatch: domainMismatch
      },
      authentication: {
        spf: spfResult,
        dkim: dkimResult,
        dmarc: dmarcResult,
        passes: authPasses,
        fails: authFails
      },
      content_analysis: contentResult,
      timing_analysis: timingResult,
      assessment_report: assessmentReport,
      verdict_reasons: reasons,
      analyzed_at: new Date().toISOString(),
      source,
      headersUnavailable,
      gmail_metadata
    });
  } catch (error: any) {
    console.error('API analyze error:', error);
    res.status(500).json({ error: error.message || 'Failed to complete email analysis.' });
  }
}

function extractDomain(input: string = ''): string {
  if (!input) return '';
  const emailMatch = input.match(/<([^>]+)>/) || input.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
  const target = emailMatch ? emailMatch[1] : input.trim();
  const atIndex = target.lastIndexOf('@');
  if (atIndex !== -1) {
    return target.slice(atIndex + 1).toLowerCase().trim().replace(/[>)\],;]+$/, '');
  }
  return target.toLowerCase().trim().replace(/^[<(\[]+/, '').replace(/[>)\],;]+$/, '');
}

async function queryDnsDoH(domain: string): Promise<string[]> {
  const cleanDomain = domain.trim().replace(/\.+$/, '');
  if (!cleanDomain) return [];
  try {
    const res = await fetch(`https://dns.google/resolve?name=${encodeURIComponent(cleanDomain)}&type=TXT`, {
      headers: { Accept: 'application/dns-json' }
    });
    if (res.ok) {
      const data = await res.json();
      if (data.Answer && Array.isArray(data.Answer)) {
        return data.Answer
          .filter((ans: any) => ans.type === 16)
          .map((ans: any) => String(ans.data || '').replace(/^"(.*)"$/, '$1').replace(/\\"/g, '"'));
      }
    }
  } catch (e) {}
  return [];
}

async function checkSpfDoH(domain: string) {
  if (!domain) return { status: 'FAIL', detail: 'No domain provided for SPF check.', record: null };
  const records = await queryDnsDoH(domain);
  const spfRecords = records.filter(r => r.trim().toLowerCase().startsWith('v=spf1'));
  if (spfRecords.length === 0) {
    return { status: 'NONE', detail: `No SPF record published for ${domain}.`, record: null };
  }
  const spf = spfRecords[0];
  const lower = spf.toLowerCase();
  if (lower.includes('+all')) {
    return { status: 'FAIL', detail: 'Permissive SPF record found (+all).', record: spf };
  }
  return { status: 'PASS', detail: `Valid SPF record found on ${domain}.`, record: spf };
}

async function checkDkimDoH(dkimHeader: string, fromDomain: string) {
  if (!dkimHeader) {
    if (fromDomain) {
      for (const sel of ['20230601', 's1', 'google', 'default']) {
        const records = await queryDnsDoH(`${sel}._domainkey.${fromDomain}`);
        const found = records.filter(r => r.includes('v=DKIM1') || r.includes('k=rsa') || r.includes('p='));
        if (found.length > 0) {
          return { status: 'PASS', detail: `DKIM verified at ${sel}._domainkey.${fromDomain}`, domain: fromDomain, selector: sel, record: found[0] };
        }
      }
    }
    return { status: 'NONE', detail: 'No DKIM-Signature header present.', domain: null, selector: null, record: null };
  }
  const sMatch = dkimHeader.match(/\bs=([a-zA-Z0-9._-]+)/i);
  const dMatch = dkimHeader.match(/\bd=([a-zA-Z0-9._-]+)/i);
  const selector = sMatch ? sMatch[1] : null;
  const domain = dMatch ? dMatch[1] : fromDomain;
  if (!selector || !domain) {
    return { status: 'FAIL', detail: 'Malformed DKIM header.', domain, selector, record: null };
  }
  const records = await queryDnsDoH(`${selector}._domainkey.${domain}`);
  const found = records.filter(r => r.includes('v=DKIM1') || r.includes('k=rsa') || r.includes('p='));
  if (found.length > 0) {
    return { status: 'PASS', detail: `DKIM public key confirmed at ${selector}._domainkey.${domain}`, domain, selector, record: found[0] };
  }
  return { status: 'FAIL', detail: `No public key found for DKIM selector.`, domain, selector, record: null };
}

async function checkDmarcDoH(domain: string) {
  if (!domain) return { status: 'FAIL', policy: null, detail: 'No domain provided for DMARC check.', record: null };
  const records = await queryDnsDoH(`_dmarc.${domain}`);
  const dmarcRecords = records.filter(r => r.trim().toLowerCase().startsWith('v=dmarc1'));
  if (dmarcRecords.length === 0) {
    return { status: 'NONE', policy: 'none_published', detail: `No DMARC policy found at _dmarc.${domain}.`, record: null };
  }
  const rec = dmarcRecords[0];
  const pMatch = rec.match(/\bp=([a-zA-Z]+)/i);
  const policyAction = pMatch ? pMatch[1].toLowerCase() : 'none';
  return { status: 'PASS', policy: policyAction, detail: `DMARC record present with policy: ${policyAction}.`, record: rec };
}

function analyzeContent(subject: string = '', body: string = '') {
  const combined = `${subject} ${body}`.toLowerCase();
  const urgencyWords = ['urgent', 'act now', 'action required', 'within 24 hours', 'immediate action', 'final notice', 'suspended immediately', 'verify immediately', 'critical alert', 'warning'];
  const finWords = ['wire transfer', 'bank details', 'invoice', 'gift card', 'routing number', 'cryptocurrency', 'bitcoin', 'payment method', 'credit card details', 'direct deposit'];
  const threatWords = ['suspended', 'unusual activity', 'unauthorized access', 'compromised', 'security breach', 'locked account', 'legal action'];

  const matchedU = urgencyWords.filter(w => combined.includes(w));
  const matchedF = finWords.filter(w => combined.includes(w));
  const matchedT = threatWords.filter(w => combined.includes(w));

  let score = Math.min(matchedU.length * 15 + matchedF.length * 20 + matchedT.length * 15, 100);
  let rating = score >= 60 ? 'HIGH' : score >= 30 ? 'MEDIUM' : 'LOW';

  const urlMatches = combined.match(/https?:\/\/[^\s"'<>]+/gi) || [];
  const rawIpUrls = urlMatches.filter(u => /https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(u));

  const matchedPhrases: { phrase: string; category: string }[] = [];
  matchedU.forEach(p => matchedPhrases.push({ phrase: p, category: 'Urgency / Pressure' }));
  matchedF.forEach(p => matchedPhrases.push({ phrase: p, category: 'Financial / Payment' }));
  matchedT.forEach(p => matchedPhrases.push({ phrase: p, category: 'Account Threat / Scare' }));

  return {
    risk_score: score,
    risk_rating: rating,
    matched_phrases: matchedPhrases,
    urgency_count: matchedU.length,
    financial_count: matchedF.length,
    threat_count: matchedT.length,
    link_count: urlMatches.length,
    raw_ip_links: rawIpUrls
  };
}

function analyzeTiming(dateHeaderStr: string = '') {
  if (!dateHeaderStr) return { parsed_date: null, hour_local: null, is_off_hours: false, detail: 'No Date header provided.' };
  const dt = new Date(dateHeaderStr);
  if (isNaN(dt.getTime())) return { parsed_date: null, hour_local: null, is_off_hours: false, detail: 'Invalid Date header.' };
  const hour = dt.getUTCHours();
  const isOffHours = (hour < 6 || hour >= 23);
  return {
    parsed_date: dt.toUTCString(),
    hour_local: hour,
    is_off_hours: isOffHours,
    detail: isOffHours ? 'Sent during off-hours window (23:00 - 06:00).' : 'Sent during normal daytime business hours.'
  };
}

function computeServerlessAssessment(params: {
  spfStatus: string;
  dkimStatus: string;
  dmarcStatus: string;
  domainMismatch: boolean;
  headersUnavailable: boolean;
  urgencyCount: number;
  financialCount: number;
  threatCount: number;
  linkCount: number;
  hasIpLink: boolean;
  isOffHours: boolean;
}) {
  const authMax = 45;
  let authScore = 0;
  const authDetails: string[] = [];

  if (params.headersUnavailable) {
    authDetails.push('Not available — no raw headers to check');
  } else {
    if (params.spfStatus === 'FAIL') {
      authScore += 18;
      authDetails.push('SPF failed (+18)');
    } else if (params.spfStatus === 'NONE') {
      authScore += 9;
      authDetails.push('SPF not published (+9)');
    }
    if (params.dkimStatus === 'FAIL' || params.dkimStatus === 'NONE') {
      authScore += 12;
      authDetails.push(params.dkimStatus === 'NONE' ? 'DKIM missing (+12)' : 'DKIM failed (+12)');
    }
    if (params.dmarcStatus !== 'PASS') {
      authScore += 10;
      authDetails.push('DMARC not enforced (+10)');
    }
    if (params.domainMismatch) {
      authScore += 5;
      authDetails.push('From/Return-Path mismatch (+5)');
    }
    if (authDetails.length === 0) {
      authDetails.push('All authentication checks passed');
    }
  }
  authScore = Math.min(authScore, authMax);

  const contentMax = 30;
  const contentScore = Math.min(
    Math.min(params.urgencyCount, 3) * 4 +
    Math.min(params.financialCount, 3) * 4 +
    Math.min(params.threatCount, 3) * 2,
    contentMax
  );

  const linkMax = 15;
  let linkScore = 0;
  if (params.hasIpLink) {
    linkScore = 15;
  } else if (params.linkCount >= 2) {
    linkScore = 5;
  }

  const timingMax = 10;
  const timingScore = params.isOffHours ? 10 : 0;

  const totalScore = authScore + contentScore + linkScore + timingScore;
  const grade = totalScore < 15 ? 'A+' : totalScore < 30 ? 'A' : totalScore < 50 ? 'B' : totalScore < 70 ? 'C' : 'F';

  return {
    authentication_risk: {
      score: authScore,
      max_score: authMax,
      weight_percentage: 45,
      signals_triggered: authDetails
    },
    content_risk: {
      score: contentScore,
      max_score: contentMax,
      weight_percentage: 30,
      signals_triggered: [`${params.urgencyCount} urgency keywords`, `${params.financialCount} financial keywords`, `${params.threatCount} threat keywords`]
    },
    link_risk: {
      score: linkScore,
      max_score: linkMax,
      weight_percentage: 15,
      signals_triggered: params.hasIpLink ? ['Raw IP link detected'] : [`${params.linkCount} URLs present`]
    },
    timing_risk: {
      score: timingScore,
      max_score: timingMax,
      weight_percentage: 10,
      signals_triggered: params.isOffHours ? ['Off-hours transmission'] : ['Normal daytime hours']
    },
    sender_alignment_risk: {
      score: params.domainMismatch ? 10 : 0,
      max_score: 10,
      weight_percentage: 10,
      signals_triggered: params.domainMismatch ? ['Sender domain mismatch'] : ['Domain aligned']
    },
    final_weighted_score: totalScore,
    max_possible_score: 100,
    overall_grade: grade,
    score_breakdown_explanation: `Overall Bayesian score is ${totalScore}/100 with Grade ${grade}.`
  };
}
